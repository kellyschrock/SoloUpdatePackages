#!/bin/sh
set -e

sololink_config --make-golden
