#!/bin/sh

echo $0 ran as expected
echo Hey stupid > /home/root/preinstall-output.txt

