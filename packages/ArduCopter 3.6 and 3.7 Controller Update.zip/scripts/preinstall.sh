#!/bin/sh

if [ -e /firmware/*.bin ]
then
    rm /firmware/*.bin
fi
